package com.example.projeto03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto03Application {

	public static void main(String[] args) {
		SpringApplication.run(Projeto03Application.class, args);
	}

}
