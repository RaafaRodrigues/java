package com.example.projeto03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
